package com.mod.mod.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mod.mod.models.Technology;



public interface TechnologyRepository extends JpaRepository<Technology, String> {

}
