package com.mod.mod.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mod.mod.models.User;

public interface UserRepository extends JpaRepository<User, Long> {

}
