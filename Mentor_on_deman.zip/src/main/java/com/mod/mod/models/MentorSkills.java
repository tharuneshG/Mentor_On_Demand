package com.mod.mod.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mentorskill")
public class MentorSkills {


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "skillname")
	private String skillname;
	
	@Column(name = "totexp")
	private String totexp;
	
	@Column(name = "selfrate")
	private String selfrate;

	@Column(name = "rating")
	private String rating;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSkillname() {
		return skillname;
	}

	public void setSkillname(String skillname) {
		this.skillname = skillname;
	}

	public String getTotexp() {
		return totexp;
	}

	public void setTotexp(String totexp) {
		this.totexp = totexp;
	}

	public String getSelfrate() {
		return selfrate;
	}

	public void setSelfrate(String selfrate) {
		this.selfrate = selfrate;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}
}
