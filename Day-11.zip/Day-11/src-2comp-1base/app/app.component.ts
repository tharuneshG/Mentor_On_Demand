import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <div>
      <my-base></my-base>
      <hr />
      <my-inherited></my-inherited>
      <hr />
      <myInh></myInh>
    </div>
  `
})
export class AppComponent { }