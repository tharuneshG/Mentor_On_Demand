import { Component, Input  } from '@angular/core';

@Component({
  selector : 'my-base',
  template: `
    <div style='background-color: yellow'>
       {{val}}
    </div>
  `
})
export class BaseComponent {
  val: string = 'Some Sample String';
}