import { Component } from '@angular/core';
import { BaseComponent } from './base.component';

@Component({
  selector : 'myInh',
  template: `
  <div style='background-color: blue'>
     {{val}}
  </div>
`
})
export class DeriveComponent extends BaseComponent {}