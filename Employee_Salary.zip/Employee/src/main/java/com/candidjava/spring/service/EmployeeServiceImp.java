package com.candidjava.spring.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.candidjava.spring.bean.Employee;

@Service
public class EmployeeServiceImp implements EmployeeService {

	private static List<Employee> employees;

	static {
		employees = dummyEmployees();
	}

	public List<Employee> getEmployee() {
		// TODO Auto-generated method stub
		return employees;
	}

	public Employee findById(int id) {
		// TODO Auto-generated method stub
		for (Employee employee : employees) {
			if (employee.getId() == id) {
				return employee;
			}
		}
		return null;
	}

	public void createEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employees.add(employee);
	}

	public void deleteEmployeeById(int id) {
		// TODO Auto-generated method stub
		Iterator<Employee> it = employees.iterator();
		while (it.hasNext()) {
			Employee user = (Employee) it.next();
			if (user.getId() == id) {
				it.remove();
			}
		}
	}

	public void updatePartially(Employee currentEmployee, int id) {
		for (Employee employee : employees) {
			if (employee.getId() == id) {
				if (currentEmployee.getSalary()!= 0) {
					employee.setId(id);
					employee.setSalary(currentEmployee.getSalary());
				}
				employee.setName(employee.getName());
				update(employee);
			}
		}

	}

	public void update(Employee employee) {
		// TODO Auto-generated method stub
		int index = employees.indexOf(employee);
		employees.set(index, employee);
	}

	private static List<Employee> dummyEmployees() {
		// TODO Auto-generated method stub
		List<Employee> employees = new ArrayList<Employee>();
		employees.add(new Employee(1, "John", 20000));
		employees.add(new Employee(2, "Ben", 300000));
		employees.add(new Employee(3, "Andrew", 600000));
		employees.add(new Employee(4, "Samuael", 50000));
		return employees;
	}

	@Override
	public int getMaxEmployee()
	{
		int maxSalary=0;
		for(int i=0;i<employees.size();i++)
		{
			if(maxSalary<=employees.get(i).getSalary())
		
			{
				maxSalary=employees.get(i).getSalary();
			}
		}
		return maxSalary;
	}
}
