package com.javasampleapproach.springrest.mysql.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.springrest.mysql.model.Employee;
import com.javasampleapproach.springrest.mysql.repo.CustomerRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class EmployeerController {

	@Autowired
	CustomerRepository repository;

	@GetMapping("/employees")
	public List<Employee> getAllEmployee() {
		System.out.println("Get all Customers...");

		List<Employee> employees = new ArrayList<>();
		repository.findAll().forEach(employees::add);

		return employees;
	}

	@PostMapping(value = "/create")
	public ResponseEntity<Void>  postCustomer(@RequestBody Employee employee) {

	  repository.save(new Employee(employee.getName(), employee.getAge(), employee.getSalary()));
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Employee> deleteEmployee(@PathVariable("id") long id) {
		System.out.println("Delete employee with ID = " + id + "...");

		repository.deleteById(id);

		return new ResponseEntity<Employee>(HttpStatus.CREATED);
	}

	@DeleteMapping("/employees/delete")
	public ResponseEntity<String> deleteAllEmployee() {
		System.out.println("Delete All Customers...");

		repository.deleteAll();

		return new ResponseEntity<>("All employees have been deleted!", HttpStatus.OK);
	}

	@GetMapping(value = "employees/age/{age}")
	public List<Employee> findByAge(@PathVariable int age) {

		List<Employee> employees = repository.findByAge(age);
		return employees;
	}

	@PutMapping("/employees/{id}")
	public ResponseEntity<Employee> updateCustomer(@PathVariable("id") long id, @RequestBody Employee employee) {
		System.out.println("Update Customer with ID = " + id + "...");

		Optional<Employee> customerData = repository.findById(id);

		if (customerData.isPresent()) {
			Employee _employee = customerData.get();
			_employee.setName(employee.getName());
			_employee.setAge(employee.getAge());
			_employee.setActive(employee.isActive());
			return new ResponseEntity<>(repository.save(_employee), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
